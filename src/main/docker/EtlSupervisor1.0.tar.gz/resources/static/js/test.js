var s = 1
